% Classical Ghost Imaging Simulation in MATLAB

clear all;
close all;
clc;

% Define parameters
width = 53;
height = 70;  % Dimensions of the image plane
num_patterns = 10;  % Number of random intensity patterns to generate

load binary_image.mat
image = I_binary;
object_img = I_binary;

% Generate random intensity patterns and simulate measurements
bucket_measurements = zeros(1, num_patterns);
patterns = zeros(width, height, num_patterns);
for k = 1:num_patterns
    pattern = rand(width, height);
    patterns(:,:,k) = pattern;
    transmitted_light = pattern .* object_img;
    bucket_measurements(k) = sum(transmitted_light, 'all');
end

% Reconstruct the object image using correlation
reconstructed_img = zeros(width, height);
for i = 1:width
    for j = 1:height
        pattern_series = squeeze(patterns(i, j, :));
        correlation = corr(bucket_measurements', pattern_series);
        reconstructed_img(i, j) = correlation;
    end
end

% Plotting
figure;
subplot(1, 2, 1);
imshow(patterns(:,:,1), []);
title('Example Intensity Pattern');
subplot(1, 2, 2);
imshow(reconstructed_img, []);
title('Reconstructed Image');

% figure;
% subplot(1, 3, 1);
% imshow(object_img, []);
% title('True Object');
% subplot(1, 3, 2);
% imshow(patterns(:,:,1), []);
% title('Example Intensity Pattern');
% subplot(1, 3, 3);
% imshow(reconstructed_img, []);
% title('Reconstructed Image');
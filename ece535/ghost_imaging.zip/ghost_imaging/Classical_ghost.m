% Classical Ghost Imaging Simulation in MATLAB

clear all;
close all;
clc;

% Define parameters
width = 50;
height = 50;  % Dimensions of the image plane
num_patterns = 2000;  % Number of random intensity patterns to generate

% Create a circular aperture as our object
object_img = zeros(width, height);
[cx, cy] = meshgrid(1:width, 1:height);
radius = 10;
mask = (cx - width/2).^2 + (cy - height/2).^2 <= radius^2;
object_img(mask) = 1;

% % % Prepare the figure for the timelapse
% figure;
% 
% % Generate random intensity patterns, simulate measurements, and display timelapse
% bucket_measurements = zeros(1, num_patterns);
% patterns = zeros(width, height, num_patterns);
% reconstructed_img_cumulative = zeros(width, height);
% correlations = zeros(width, height);
% 
% for k = 1:num_patterns
%     pattern = rand(width, height);
%     patterns(:,:,k) = pattern;
%     transmitted_light = pattern .* object_img;
%     bucket_measurements(k) = sum(transmitted_light, 'all');
% 
%     % Update the correlations and reconstructed image for the current pattern
%     correlations = correlations + (bucket_measurements(k) - mean(bucket_measurements(1:k))) * (patterns(:,:,k) - mean(patterns(:,:,1:k), 3));
%     reconstructed_img_cumulative = correlations / k;
% 
%     % Display the current pattern and the reconstructed image up to now
%     subplot(1, 2, 1);
%     imshow(pattern, []);
%     title(['Pattern ', num2str(k)]);
% 
%     subplot(1, 2, 2);
%     imshow(reconstructed_img_cumulative, []);
%     title(['Reconstruction (', num2str(k), ' patterns)']);
% 
%     pause(0.001); % Pause to let the user see the update (adjust as needed)
% end

% Generate random intensity patterns and simulate measurements
bucket_measurements = zeros(1, num_patterns);
patterns = zeros(width, height, num_patterns);
for k = 1:num_patterns
    pattern = rand(width, height);
    patterns(:,:,k) = pattern;
    transmitted_light = pattern .* object_img;
    bucket_measurements(k) = sum(transmitted_light, 'all');
end

% Reconstruct the object image using correlation
reconstructed_img = zeros(width, height);
for i = 1:width
    for j = 1:height
        pattern_series = squeeze(patterns(i, j, :));
        correlation = corr(bucket_measurements', pattern_series);
        reconstructed_img(i, j) = correlation;
    end
end

% Plotting
figure;
subplot(1, 3, 1);
imshow(object_img, []);
title('True Object');
subplot(1, 3, 2);
imshow(patterns(:,:,1), []);
title('Example Intensity Pattern');
subplot(1, 3, 3);
imshow(reconstructed_img, []);
title('Reconstructed Image');
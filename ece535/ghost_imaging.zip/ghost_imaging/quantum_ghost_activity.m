clear all

% Define the simulation parameters
dim = 50;
num_patterns = 10;
correlationDegree = 1; % Degree of correlation between entangled photons (0 to 1)

% Create a list of filenames
filenames = {'binary_image_50x50.mat', 'binary_image_50x50_B.mat'};

% Randomly select one filename
selectedFile = filenames{randi([1, 2])};

% Load the selected file
load(selectedFile);
image = I_binary;
object = image;

% Simulate entangled pairs as correlated random patterns
patterns_reference = rand(dim, dim, num_patterns);
patterns_object = correlationDegree * patterns_reference + (1-correlationDegree) * rand(dim, dim, num_patterns);

%Simulate the imaging process
bucket_detector_signals = squeeze(sum(sum(patterns_object .* repmat(image, [1, 1, num_patterns]))));

% Reconstruct the image using correlations
reconstructed_image = zeros(dim,dim);
for i = 1:num_patterns
    delta_signal = bucket_detector_signals(i) - mean(bucket_detector_signals);
    reconstructed_image = reconstructed_image + delta_signal .* squeeze(patterns_reference(:,:,i));
end

reconstructed_image = (reconstructed_image - min(min(reconstructed_image))) / (max(max(reconstructed_image)) - min(min(reconstructed_image)));

% Plotting the original and reconstructed images
figure;
%subplot(1, 2, 1);
%imshow(image, [],'InitialMagnification', 800);
%title('Object');

%subplot(1, 2, 2);
imshow(reconstructed_image, [],'InitialMagnification', 800);
title('Reconstructed Image');

